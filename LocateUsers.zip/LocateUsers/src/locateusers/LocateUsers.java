package locateusers;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;
import twitter4j.GeoLocation;
import twitter4j.IDs;
import twitter4j.Query;
import twitter4j.QueryResult;
import twitter4j.Status;
import twitter4j.Twitter;
import twitter4j.TwitterException;
import twitter4j.TwitterFactory;
import twitter4j.conf.ConfigurationBuilder;


public class LocateUsers extends Thread {
    public static void main(String [] args){
        //Create thread and start it running
        LocateUsers simpleThread = new LocateUsers ();
        simpleThread.start();
    }    
    
    //Inherited from Thread - this method is executed when the thread is started.
    @Override
    public void run(){
        //Set up user authentication - YOU NEED TO ENTER YOUR AUTHENTICATION KEYS HERE
        ConfigurationBuilder configBuilder = new ConfigurationBuilder();
        configBuilder.setOAuthConsumerKey("WWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWW");
        configBuilder.setOAuthConsumerSecret("WWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWW");
        configBuilder.setOAuthAccessToken("WWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWW");
        configBuilder.setOAuthAccessTokenSecret("WWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWW");

        //Create instance of Twitter for searching etc.
        TwitterFactory tf = new TwitterFactory(configBuilder.build());
        Twitter twitter = tf.getInstance();

//         
            double lat = 51.513890;
            double lon = -0.226670;
            int rad = 5;
            
            
            QueryResult result = null;
                                       
               Query query = new Query().geoCode(new GeoLocation(lat,lon), rad, "km");
               
            query.setCount(50);
            query.setLang("en");
            
            
               HashMap<Long, Boolean> userHashMap = new HashMap<>();       
       
        try {
            result = twitter.search(query);
        } catch (TwitterException ex) {
            Logger.getLogger(LocateUsers.class.getName()).log(Level.SEVERE, null, ex);
        }
                                       
           try{
               
            List<Status> tweets = result.getTweets();
  
           
            for (Status tweet: tweets) {
                userHashMap.put(tweet.getUser().getId(), true);
            }
            Set<Long> userIDs = userHashMap.keySet();                
            List<Long> userIDsList = new ArrayList<>(userIDs);
            
           
            int page = -1;
            
            IDs friendsids = twitter.getFriendsIDs(userIDsList.get(0), page);
            
            ArrayList<Long> friendslist = new ArrayList<>();
            
            //List<Long> newlist = Arrays.asList(friendsids.getIDs());

            
            long[] array = friendsids.getIDs();

            for (int i=0; i<friendsids.getIDs().length; i++) {
                System.out.println(array[i]);
                friendslist.add(array[i]);
            }
            
            // To store followers' id along with user id to whom they are following
            HashMap<Long, ArrayList<Long>> followerMap = new HashMap();
            
            
                     followerMap.put(userIDsList.get(0), friendslist);
            
            System.out.println(tweets.size());

            
        }
        catch(Exception ex){
            ex.printStackTrace();
        }
    }
}
