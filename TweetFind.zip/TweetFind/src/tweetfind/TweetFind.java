/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tweetfind;

import java.util.HashMap;
import java.util.List;
import java.util.Set;
import twitter4j.*;
import twitter4j.conf.ConfigurationBuilder;


public class TweetFind {
    HashMap<String, Integer> map = new HashMap<>();
   
    public  void loadData(String key1) {
        //Set up user authentication - YOU NEED TO ENTER YOUR AUTHENTICATION KEYS HERE
        ConfigurationBuilder configBuilder = new ConfigurationBuilder();
        configBuilder.setOAuthConsumerKey("WWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWW");
        configBuilder.setOAuthConsumerSecret("WWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWW");
        configBuilder.setOAuthAccessToken("WWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWW");
        configBuilder.setOAuthAccessTokenSecret("WWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWW");


        
        
        //Create instance of Twitter for searching etc.
        TwitterFactory tf = new TwitterFactory(configBuilder.build());
        Twitter twitter = tf.getInstance();
        
        //Build query. Types of search listed here: https://dev.twitter.com/rest/public/search
        Query query = new Query(key1);
            
        //Number of results pulled each time
        query.setCount(20);
        
        //Set the language of the tweets that we want 
        query.setLang("en");//Language codes listed here: https://en.wikipedia.org/wiki/ISO_639-1
            
        //How many results do we want to retrieve
        int numResults = 100;
        
        //Filter out duplicate tweets and keep track of how many tweets we have downloaded
        HashMap<Long, Boolean> tweetIDMap = new HashMap();
        
        try{
            //Run query without max_id set
            QueryResult result = twitter.search(query);
        
            //Run query  until we have the required number of tweets or until there are no more tweets.
            while (result.getCount() > 0 && tweetIDMap.size() <= numResults){
                //Minimum ID of the returned results. Used to get sequence of tweets. See https://dev.twitter.com/rest/public/timelines
                long minID = -1;

                //Get the results
                List<Status> tweets = result.getTweets();

                
                
                //Work through the results
                for (Status tweet : tweets) {
                    printTweet(tweet);
                    
                    //Track min id so we can get the next 'page'
                    if(minID == -1 || tweet.getId() < minID)
                        minID = tweet.getId();

                    //Store ID in hash map to keep track of number of tweets
                    tweetIDMap.put(tweet.getId(), Boolean.TRUE);
                    
                    //System.out.println("USERNAME:" + tweet.getUser().getScreenName());
                }
                //int freq1 = map.get(key1);
                //int freq2 = map.get(key2);
                //int freq3 = map.get(key3);

                //Set the query to the minimum ID of the previous search minus 1
                query.setMaxId(minID-1);

                //Run the search again
                result = twitter.search(query);
               
            }
            
            System.out.println(tweetIDMap.size() + " unique tweets downloaded.");
            
        }
        catch(TwitterException ex){
            ex.printStackTrace();
        }
    }
    
    
    //Prints out information about the tweet
    public void printTweet(Status tweet){
        //Get information about the tweet
//        String userName = tweet.getUser().getName();
//        Date creationDate = tweet.getCreatedAt();
        String tweetText = tweet.getText();
        
        
        //String[] words = tweetText.toLowerCase().split("\\s");
              // Create a TreeMap to hold words as key and count as value

      String[] words = tweetText.toLowerCase().split("[ \n\t\r.,;:!?(){]");
      
      String[] words1 = new String[words.length];
      
      for (int i = 0; i < words.length; i++) {
          String word = words[i].replaceAll("\\P{L}+", "");
          
          
          words1[i] = word;
      }
      
      for (int i = 0; i < words1.length; i++) {
          
          
          String key = words1[i].trim();
        
        if (key.length() > 3) {
          if (!map.containsKey(key)) {
            map.put(key, 1);
          }
          else {
            int value = map.get(key);
            value++;
            map.put(key, value);
          }
        }
      }
      
      Set<String> keys = map.keySet();
     
      for (String k : keys) {         
          int val = map.get(k);   
          //System.out.println("Key: " + k + " Count: " + val);
          
         
      } 
      
      
      }

}
      
      
      
      //System.out.println("THE SIZE OF THE WORDS ARRAY: " + words1.length);
  
// Get all entries into a set
//Set<Map.Entry<String, Integer>> entrySet = map.entrySet();

// Get key and value from each entry
      //for (Map.Entry<String, Integer> entry: entrySet)
      //  System.out.println(entry.getValue() + "\t" + entry.getKey());
    
    
        
        //Print out the information
        //System.out.println("Tweet created by " + userName + " on date " + creationDate);
        //System.out.println("Tweet text " + tweetText);
        //System.out.println( "words" + Arrays.toString(words));
   // }
    
//}

