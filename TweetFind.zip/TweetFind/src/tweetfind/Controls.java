/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tweetfind;

import javafx.application.Application;
import static javafx.application.Application.launch;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.chart.PieChart;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

public class Controls extends Application {
    TweetFind tweetfind = new TweetFind();
    PieChart chart = new PieChart();
    
    public static void main(String[] args) {
        launch(args);
    }
   
        TextField textField4 = new TextField("Word"); 
        Button button = new Button("Here");
     
        
        TextField textField = new TextField("Type here"); 
        TextField textField2 = new TextField("Type here");
        TextField textField3 = new TextField("Type here");
        Button button2 = new Button("Here");

    @Override
    public void start(Stage primaryStage) throws Exception {

        TweetFind tweetfind = new TweetFind();

        
        GridPane gPane = new GridPane();
           gPane.add(chart,1,10);
           
        gPane.setPadding(new Insets(5));
        gPane.setVgap(10);
           
               gPane.add(new Label("Search word: "), 0, 0);
        gPane.add(textField4, 1, 0); 
       
        
        gPane.add(button, 2, 0);
        
       button.setOnAction (e -> {
                     gPane.add(new Label("Keyword 1: "), 0, 2);
        gPane.add(textField, 1, 2); 

        gPane.add(new Label("Keyword 2: "), 0, 3);
        gPane.add(textField2, 1, 3); 
        
        gPane.add(new Label("Keyword 3: "), 0, 4);
        gPane.add(textField3, 1, 4); 
        
        gPane.add(new Label("Search"), 2, 6);
             
        gPane.add(button2, 2, 6); 
       tweetfind.loadData(textField4.getText());
       });
       
   
      
        
    
    
        button2.setOnAction (e -> {
            
                chart.getData().clear();
            
         
             
             String firstWord = textField.getText();
             String secondWord = textField2.getText();
             String thirdWord = textField3.getText();
             
             int firstVal = 0, secondVal = 0, thirdVal = 0;
             
             if (tweetfind.map.containsKey(firstWord))
                firstVal = tweetfind.map.get(firstWord);
             if (tweetfind.map.containsKey(secondWord))
                secondVal = tweetfind.map.get(secondWord);
             if (tweetfind.map.containsKey(thirdWord))
                thirdVal = tweetfind.map.get(thirdWord);
            
                    ObservableList<PieChart.Data> pieChartData
                = FXCollections.observableArrayList();
                    
                    System.out.println(firstWord);
                    System.out.println(secondWord);
                    System.out.println(thirdWord);
                    System.out.println(firstVal);
                    System.out.println(secondVal);
                    System.out.println(thirdVal);
                    
                    
                    
        pieChartData.addAll(
                new PieChart.Data(firstWord, firstVal),
                new PieChart.Data(secondWord, secondVal),
                new PieChart.Data(thirdWord, thirdVal));

        PieChart chart = new PieChart(pieChartData);
        chart.setTitle("Number of times chosen words is tweeted");
    
        GridPane.setConstraints(chart, 0, 10);
        gPane.getChildren().add(chart);
      
             
                 });
        
        Scene myScene = new Scene(gPane);

        primaryStage.setScene(myScene);
        primaryStage.setTitle("Basic controls");
        primaryStage.setWidth(860);
        primaryStage.setHeight(620);
        primaryStage.show();
    }
    

}
